function [ symbol ] = gardner_symbol_recovery( samples, sps )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
avg=5;
error=2;
symbol=zeros(1,numel(samples)/sps-1);
inner=1;
offset=2;
offsetvec=[];
thesame=0;
for outer=1:numel(samples)/sps-1
    current_start=(outer-1)*sps+offset;
    symbol(outer)=samples(current_start);
    if thesame>20
        k=0.001;
    else
        k=0.02;
    end
    error=error+k*(samples(current_start+sps/2)*(samples(current_start)-samples(current_start+sps)))
    if offset==round(error)
        thesame=thesame+1;
    else
        thesame=0;
        offset=round(error);
    end
    %offset=1;
    offsetvec=[offsetvec offset];
end
figure();
plot(offsetvec)
grid on
end

